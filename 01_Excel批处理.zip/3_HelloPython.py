import pandas as pd
import numpy as np
import os
from pandas import DataFrame

input_file = r"F:\05盐碱地数据处理任务20250106\样点表格汇总\新样点_20250312\样点校核\合并\大安.xls"
output_root = r"F:\05盐碱地数据处理任务20250106\样点表格汇总\新样点_20250312\样点校核\处理结果"  # 新建的专用输出目录

os.makedirs(output_root, exist_ok=True)
def process_step1(input_file):
    """第一步：JHD处理（修复版本）"""
    df = pd.read_excel(input_file)
    df_copy = df.copy()

    # 转换为数值类型
    df_copy['JHD'] = pd.to_numeric(df_copy['JHD'], errors='coerce')

    # 删除空值行（包含转换产生的NaN）
    df_clean = df_copy.dropna(subset=['SRXYZL', 'JHD'], how='any')

    # 过滤JHD值
    df_filtered = df_clean[df_clean['JHD'] <= 1]

    # 统计结果
    stats = {
        "处理前数量": len(df_clean),
        "处理后数量": len(df_filtered),
        "JHD最小值": df_filtered['JHD'].min(),
        "JHD最大值": df_filtered['JHD'].max()
    }
    output_path = os.path.join(output_root, "JHD处理结果.xlsx")
    df_filtered.to_excel(output_path, index=False)
    return stats


def process_step2(input_file):
    """第二步：YZL处理（修复版本）"""
    df = pd.read_excel(input_file)
    df_copy = df.copy()

    # 转换为数值类型
    df_copy['JHD'] = pd.to_numeric(df_copy['JHD'], errors='coerce')
    df_copy['SRXYZL'] = pd.to_numeric(df_copy['SRXYZL'], errors='coerce')

    # 删除空值行
    df_clean = df_copy.dropna(subset=['SRXYZL', 'JHD'], how='any')
    original_count = len(df_clean)

    # 统计指标计算
    data = df_clean['SRXYZL']
    stats_before = {
        "最小值": data.min(),
        "最大值": data.max(),
        "平均值": data.mean(),
        "标准差": data.std(),
        "变异系数": (data.std() / data.mean()) * 100 if data.mean() != 0 else np.nan
    }

    # 四分位数处理
    Q1 = data.quantile(0.25)
    Q3 = data.quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR

    df_filtered = df_clean[(data >= lower) & (data <= upper)]
    removed_count = original_count - len(df_filtered)

    output_path = os.path.join(output_root, "YZL处理结果.xlsx")
    df_filtered.to_excel(output_path, index=False)
    return stats_before, original_count, removed_count, len(df_filtered)


def process_step3(input_file, output_root, ion_columns=['CO3', 'HCO3', 'SO4', 'Cl']):
    """
    第三步增强版：联合过滤多个离子列

    参数：
    input_file -- 输入文件路径
    output_root -- 输出目录路径
    ion_columns -- 需要联合验证的离子列列表

    返回：
    包含处理结果的字典
    """
    # 读取原始数据
    df = pd.read_excel(input_file)
    original_count = len(df)

    # 创建副本处理
    df_copy = df.copy()

    # 转换所有指定列为数值类型
    for col in ion_columns:
        df_copy[col] = pd.to_numeric(df_copy[col], errors='coerce')

    # 删除任意离子列存在空值的行
    df_clean = df_copy.dropna(subset=ion_columns, how='any')

    # 计算处理结果
    result_stats = {
        "处理前总数": original_count,
        "删除行数": original_count - len(df_clean),
        "处理后总数": len(df_clean),
        "各列有效性": {
            col: f"{df_clean[col].notna().sum()}/{original_count}"
            for col in ion_columns
        }
    }

    # 输出文件
    output_path = os.path.join(output_root, "各个离子.xlsx")
    df_clean.to_excel(output_path, index=False)
    print(f"联合处理文件已保存至：{output_path}")

    return result_stats


def batch_processing():
    # 获取所有xls文件
    xls_files = [f for f in os.listdir(input_folder)
                 if f.endswith(('.xls', '.xlsx'))]

    # 创建各步骤输出目录
    step_dirs = {
        'step1': '01_JHD处理',
        'step2': '02_YZL处理',
        'step3': '03_离子处理'
    }
    for d in step_dirs.values():
        os.makedirs(os.path.join(output_root, d), exist_ok=True)
    # 处理每个文件
    for file in xls_files:
        base_name = os.path.splitext(file)[0]
        input_path = os.path.join(input_folder, file)

        # 第一步处理
        step1_output = os.path.join(output_root, step_dirs['step1'],
                                    f"{base_name}_JHD处理结果.xlsx")
        process_step1(input_path, step1_output)

        # 第二步处理
        step2_output = os.path.join(output_root, step_dirs['step2'],
                                    f"{base_name}_YZL处理结果.xlsx")
        process_step2(input_path, step2_output)

        # 第三步处理
        step3_output = os.path.join(output_root, step_dirs['step3'],
                                    f"{base_name}_离子处理结果.xlsx")
        process_step3(input_path, step3_output)


# 主程序
if __name__ == "__main__":
    batch_processing()