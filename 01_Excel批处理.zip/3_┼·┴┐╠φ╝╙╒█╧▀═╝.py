# from openpyxl import load_workbook
# from openpyxl.chart import LineChart, Reference
#
#
# def add_line_charts(input_path, output_path):
#     """
#     修正图例显示的版本
#     横坐标：OID
#     数据列：Water_frequency 和 Habitat_suitability
#     """
#     # 加载工作簿
#     wb = load_workbook(input_path)
#
#     # 遍历所有工作表
#     for sheet in wb.worksheets:
#         # 跳过没有数据的工作表
#         if sheet.max_row < 2:
#             continue
#
#         # 创建折线图对象
#         chart = LineChart()
#         chart.title = "Wetness vs Habitat Suitability Trend"
#         chart.style = 13
#         chart.y_axis.title = 'Value'
#         chart.x_axis.title = 'Distance'
#         chart.height = 12
#         chart.width = 20
#
#         # 定义数据范围（包含标题）
#         data = Reference(sheet,
#                          # min_col=3,  # Water_frequency在第3列
#                          # max_col=4,  # Habitat_suitability在第4列
#                          # min_row=1,  # 包含标题行！！！
#                          # max_row=sheet.max_row)
#                          min_col=7,  # Water_frequency在第3列
#                          max_col=8,  # Habitat_suitability在第4列
#                          min_row=1,  # 包含标题行！！！
#                          max_row=sheet.max_row)
#
#         # 定义横坐标范围（OID在第1列，不含标题）
#         categories = Reference(sheet,
#                                min_col=6,
#                                min_row=2,  # 从数据行开始
#                                max_row=sheet.max_row)
#
#         # 添加数据并应用标题
#         chart.add_data(data, titles_from_data=True)  # 关键修正：从数据范围获取标题
#         chart.set_categories(categories)
#
#         # 自定义线条样式
#         series_water = chart.series[0]
#         series_habitat = chart.series[1]
#
#         # 设置颜色
#         series_water.graphicalProperties.line.solidFill = "0072B2"  # 蓝色
#         series_habitat.graphicalProperties.line.solidFill = "D55E00"  # 橙色
#
#         # 添加平滑曲线
#         series_water.smooth = True
#         series_habitat.smooth = True
#
#         # 将图表插入工作表
#         sheet.add_chart(chart, "H2")
#
#     # 保存文件
#     wb.save(output_path)
#
#
#
# # 使用示例
# # input_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\大安筛选版\水分和生境适宜性_Wetness_3Km_汇总修改.xlsx"
# # output_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\大安筛选版\水分和生境适宜性_Wetness_3Km_汇总修改加折线.xlsx"
# input_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\newResults\smooth55_8Km\Table_FrogDIY_Wetness修改.xlsx"
# output_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\newResults\smooth55_8Km\Table_FrogDIY_Wetness修改加折线.xlsx"
# add_line_charts(input_file, output_file)


from openpyxl import load_workbook
from openpyxl.chart import LineChart, Reference


def add_line_charts(input_path, output_path):
    """
    修正图例显示的版本
    横坐标：OID
    数据列：Water_frequency 和 Habitat_suitability
    """
    # 加载工作簿
    wb = load_workbook(input_path)

    # 遍历所有工作表
    for sheet in wb.worksheets:
        # 跳过没有数据的工作表
        if sheet.max_row < 2:
            continue

        # 创建折线图对象
        chart = LineChart()
        chart.title = "Wetness vs Habitat Suitability Trend"
        chart.style = 13
        chart.y_axis.title = 'Value'
        chart.x_axis.title = 'Distance'
        chart.height = 16
        chart.width = 22

        # +++ 新增代码：设置纵轴范围0-1 +++
        chart.y_axis.scaling.min = 0
        chart.y_axis.scaling.max = 1

        # +++ 新增代码：设置图例位置在横轴下方（底部） +++
        chart.legend.position = 'b'

        # 新增代码：设置网格线透明度和宽度
        # chart.y_axis.majorGridlines.graphicalProperties.line.solidFill = "D9D9D9"  # 浅灰色模拟透明度
        # chart.y_axis.majorGridlines.graphicalProperties.line.width = 0.25 * 12700  # 0.25磅转EMU单位
        # chart.x_axis.majorGridlines.graphicalProperties.line.solidFill = "D9D9D9"  # 同步设置X轴网格线

        # 新增代码：在横轴0处添加竖线（通过设置横轴交叉点）
        # chart.x_axis.crosses = "min"  # 强制横轴从最小值开始
        # chart.x_axis.axPos = "l"  # 确保横轴显示在左侧
        # chart.x_axis.graphicalProperties.line.solidFill = "000000"  # 设置黑色轴线
        # chart.x_axis.graphicalProperties.line.width = 12700  # 1磅的轴线宽度

        # 定义数据范围（包含标题）
        data = Reference(sheet,
                         min_col=7,
                         max_col=8,
                         min_row=1,
                         max_row=sheet.max_row)

        # 定义横坐标范围（OID在第6列，不含标题）
        categories = Reference(sheet,
                               min_col=6,
                               min_row=2,
                               max_row=sheet.max_row)

        # 添加数据并应用标题
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(categories)

        # 自定义线条样式
        series_water = chart.series[0]
        series_habitat = chart.series[1]

        # 设置颜色
        series_water.graphicalProperties.line.solidFill = "0072B2"  # 蓝色
        series_habitat.graphicalProperties.line.solidFill = "D55E00"  # 橙色

        # 添加平滑曲线
        series_water.smooth = True
        series_habitat.smooth = True

        # 将图表插入工作表
        sheet.add_chart(chart, "H2")

    # 保存文件
    wb.save(output_path)


# 使用示例（保持不变）
#     input_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\newResults\smooth55_8Km\Table_FrogDIY_Wetness修改.xlsx"
#     output_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\newResults\smooth55_8Km\Table_FrogDIY_Wetness修改加折线.xlsx"
input_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Table_Excel\Frog_Wet_1_re.xlsx"
output_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Table_Excel\Frog_Wet_1_re_picture.xlsx"
# input_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Table_Excel\Frog_Wet_2_re.xlsx"
# output_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Table_Excel\Frog_Wet_2_re_picture.xlsx"
# input_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Table_Excel\Frog_Wet_3_re.xlsx"
# output_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Table_Excel\Frog_Wet_3_re_picture.xlsx"
add_line_charts(input_file, output_file)
