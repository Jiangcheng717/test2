import pandas as pd
import numpy as np
import os
from pandas import DataFrame

input_file = r"F:\05盐碱地数据处理任务20250106\样点表格汇总\新样点_20250312\样点校核\合并\xlsx\农安.xlsx"
output_dir = r"F:\05盐碱地数据处理任务20250106\样点表格汇总\新样点_20250312\样点校核\处理结果"  # 新建的专用输出目录

os.makedirs(output_dir, exist_ok=True)
def process_step1(input_file):
    """第一步：JHD处理（修复版本）"""
    df = pd.read_excel(input_file)
    df_copy = df.copy()

    # 转换为数值类型
    df_copy['JHD'] = pd.to_numeric(df_copy['JHD'], errors='coerce')

    # 删除空值行（包含转换产生的NaN）
    df_clean = df_copy.dropna(subset=['JHD'], how='any')

    # 过滤JHD值
    df_filtered = df_clean[df_clean['JHD'] <= 1]
    df_filtered = df_clean[df_clean['JHD'] >0]

    # 统计结果
    stats = {
        "处理前数量": len(df_copy),
        "删除空行": len(df_copy)-len(df_clean),
        "删除空行后":len(df_clean),
        "大于1的异常值数量":len(df_clean)-len(df_filtered),
        "处理后数量": len(df_filtered),
        "JHD最小值": df_filtered['JHD'].min(),
        "JHD最大值": df_filtered['JHD'].max()
    }
    output_path = os.path.join(output_dir, "JHD处理结果.xlsx")
    df_filtered.to_excel(output_path, index=False)
    return stats


def process_step2(input_file):
    """第二步：YZL处理（修复版本）"""
    df = pd.read_excel(input_file)
    df_copy = df.copy()

    # 转换为数值类型
    # df_copy['JHD'] = pd.to_numeric(df_copy['JHD'], errors='coerce')
    df_copy['SRXYZL'] = pd.to_numeric(df_copy['SRXYZL'], errors='coerce')

    # 删除空值行
    df_clean = df_copy.dropna(subset=['SRXYZL'], how='any')
    # df_clean = df_clean[df_clean['SRXYZL'] <= 1]
    original_count = len(df_copy)
    delete_null =original_count-len(df_clean)
    delete_then = len(df_clean)
    # 统计指标计算
    data = df_clean[df_clean['SRXYZL'] > 0]
    data = df_clean['SRXYZL']
    stats_before = {
        "最小值": data.min(),
        "最大值": data.max(),
        "平均值": data.mean(),
        "标准差": data.std(),
        "变异系数": (data.std() / data.mean()) * 100 if data.mean() != 0 else np.nan
    }

    # 四分位数处理
    Q1 = data.quantile(0.25)
    Q3 = data.quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR

    df_filtered = df_clean[(data >= lower) & (data <= upper)]
    removed_count = delete_then - len(df_filtered)

    output_path = os.path.join(output_dir, "YZL处理结果.xlsx")
    df_filtered.to_excel(output_path, index=False)
    return stats_before, original_count, delete_null, delete_then,removed_count, len(df_filtered)


def process_step3_combined(input_file, output_dir, ion_columns=['CO3', 'HCO3', 'SO4', 'Cl']):
    """
    第三步增强版：联合过滤多个离子列

    参数：
    input_file -- 输入文件路径
    output_dir -- 输出目录路径
    ion_columns -- 需要联合验证的离子列列表

    返回：
    包含处理结果的字典
    """
    # 读取原始数据
    df = pd.read_excel(input_file)
    # df_copy = df.copy()
    # df_copy['SRXYZL'] = pd.to_numeric(df_copy['SRXYZL'], errors='coerce')


    # 创建副本处理
    df_copy = df.copy()
    df_copy['SRXYZL'] = pd.to_numeric(df_copy['SRXYZL'], errors='coerce')
    df_copy = df_copy[df_copy['SRXYZL'] >= 1]
    original_count = len(df_copy[df_copy['SRXYZL'] >= 1])
    # 转换所有指定列为数值类型
    for col in ion_columns:
        df_copy[col] = pd.to_numeric(df_copy[col], errors='coerce')
    # df_copy['JHD'] = pd.to_numeric(df_copy['JHD'], errors='coerce')
    # 删除任意离子列存在空值的行
    df_clean = df_copy.dropna(subset=ion_columns, how='any')
    # 计算处理结果
    result_stats = {
        "处理前总数": original_count,
        "删除行数": original_count - len(df_clean),
        # "删除异常点":
        "处理后总数": len(df_clean),
        "各列有效性": {
            col: f"{df_clean[col].notna().sum()}/{original_count}"
            for col in ion_columns
        }
    }

    # 输出文件
    output_path = os.path.join(output_dir, "各个离子.xlsx")
    df_clean.to_excel(output_path, index=False)
    print(f"联合处理文件已保存至：{output_path}")

    return result_stats




# 主程序
if __name__ == "__main__":
    # input_file = "F:\\05盐碱地数据处理任务20250106\\样点表格汇总\\新样点_20250312\\样点校核\\汇总\\样点合并_cxl.xlsx"  # 替换为实际文件路径

    # 第一步处理
    step1_stats = process_step1(input_file)
    print("第一步完成 - JHD处理结果：")
    print(f"原始采样点个数: {step1_stats['处理前数量']}")
    print(f"缺失样点个数: {step1_stats['删除空行']}")
    print(f"有效样点个数: {step1_stats['删除空行后']}")
    # print(f"大于1的异常值数量: {step1_stats['大于1的异常值数量']}")
    print(f"剔除大于1异常值处理后数量: {step1_stats['处理后数量']}")
    print(f"JHD最小值: {step1_stats['JHD最小值']:.4f}")
    print(f"JHD最大值: {step1_stats['JHD最大值']:.4f}\n")

    # 第二步处理
    stats_before, original, delete,delete_then,removed, remaining = process_step2(input_file)
    print("第二步完成 - YZL处理结果：")
    print(f"原始采样点个数: {original}")
    print(f"缺失样点个数: {delete}")
    print(f"有效样点个数: {delete_then}")
    # print(f"YZL大于1: {delete_then}")
    print(f"四分法剔除样点个数: {removed}")
    print(f"剔除样点数后数量: {remaining}")
    print("\nYZL删除前统计指标：")
    for k, v in stats_before.items():
        if k == "变异系数":
            print(f"{k}: {v:.2f}%")
        else:
            print(f"{k}: {v:.4f}")

    # 第三步处理
    # ion_columns = ['CO3', 'HCO3', 'SO4', 'Cl']
    ion_stats = process_step3_combined(input_file, output_dir)
    print("\n第三步完成 - 离子处理结果：")
    # 打印统计结果
    print("\n联合处理结果：")
    print(f"原始总数据量：{ion_stats['处理前总数']}")
    print(f"删除无效行数：{ion_stats['删除行数']}")
    print(f"有效数据总量：{ion_stats['处理后总数']}")
    print("\n各列有效数据统计：")
    for col, ratio in ion_stats['各列有效性'].items():
        print(f"{col}: {ratio}")
    # for col, stats in step3_stats.items():
    #     print(f"\n{col}处理：")
    #     print(f"原始数据量: {stats['处理前数量']}")
    #     print(f"删除无效值: {stats['删除数量']}")
    #     print(f"剩余有效值: {stats['处理后数量']}")