import pandas as pd
from typing import Dict


def multi_sheet_moving_average(
        input_file: str,
        output_file: str,
        input_col: str = "value",
        output_col: str = "MA",
        input_col2: str = "value",
        output_col2: str = "MA",
        window_size: int = 3,
        min_periods: int = 1,
        keep_sheets: bool = True
) -> None:
    """
    处理多工作表的Excel文件滑动平均

    参数：
    input_file: 输入文件路径
    output_file: 输出文件路径
    input_col: 需要计算的列名
    output_col: 输出列名
    window_size: 滑动窗口大小
    min_periods: 最小数据点数
    keep_sheets: 保留原始工作表结构
    """
    try:
        # 读取所有工作表
        sheets: Dict[str, pd.DataFrame] = pd.read_excel(
            input_file, sheet_name=None, engine='openpyxl'
        )

        processed_sheets = {}
        error_sheets = []

        # 处理每个工作表
        for sheet_name, df in sheets.items():
            try:
                # 验证数据列
                if input_col not in df.columns:
                    raise ValueError(f"列 '{input_col}' 不存在于工作表 [{sheet_name}]")

                # 执行滑动平均计算
                df[output_col] = df[input_col].rolling(
                    window=window_size,
                    min_periods=min_periods
                ).mean()
                df[output_col2] = df[input_col2].rolling(
                    window=window_size,
                    min_periods=min_periods
                ).mean()

                processed_sheets[sheet_name] = df
            except Exception as e:
                print(f"工作表 [{sheet_name}] 处理失败: {str(e)}")
                error_sheets.append(sheet_name)
                if keep_sheets:
                    processed_sheets[sheet_name] = df  # 保留原始数据

        # 保存结果
        with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
            for sheet_name, df in processed_sheets.items():
                df.to_excel(
                    writer,
                    sheet_name=sheet_name,
                    index=False
                )

        print(f"处理完成。成功处理 {len(processed_sheets) - len(error_sheets)} 个工作表")
        if error_sheets:
            print(f"以下工作表处理出错: {', '.join(error_sheets)}")

    except FileNotFoundError:
        print(f"错误：文件 {input_file} 未找到")
    except Exception as e:
        print(f"全局错误: {str(e)}")


# # 使用示例
# if __name__ == "__main__":
#     multi_sheet_moving_average(
#         input_file="multi_sheet_data.xlsx",
#         output_file="processed_result.xlsx",
#         input_col="temperature",  # 需要计算的列
#         output_col="MA_temp",  # 输出列名
#         window_size=5,  # 滑动窗口
#         min_periods=2,  # 最小有效数据点数
#         keep_sheets=True  # 保留出错工作表原始数据
#     )

# 使用示例
if __name__ == "__main__":
    # 参数设置
    multi_sheet_moving_average(
        input_file=r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\大安筛选版\水分和生境适宜性_NDMI_汇总.xlsx",
        output_file=r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\大安筛选版\水分和生境适宜性_NDMI_汇总.xlsx",
        # sheet_name="Sheet1",
        input_col="frog",  # 需要计算的列
        output_col="frog_average",  # 输出列名
        input_col2="NDMI_1",  # 需要计算的列
        output_col2="NDMI_average",  # 输出列名
        window_size=5,  # 滑动窗口大小
        min_periods=2  # 至少需要2个数据点才计算
    )
    """
       对Excel表格执行滑动平均计算

       参数：
       input_file: 输入Excel文件路径
       output_file: 输出Excel文件路径
       sheet_name: 工作表名称（默认为"Sheet1"）
       input_col: 需要计算的列名
       output_col: 输出列名（默认为"MA"）
       window_size: 滑动窗口大小（默认为3）
       min_periods: 计算所需最小数据点数（默认为1）
       """