import pandas as pd
from openpyxl import load_workbook
from openpyxl.chart import LineChart, Reference
from openpyxl.utils.dataframe import dataframe_to_rows

# 输入输出文件路径
input_excel = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\大安筛选版\水分和生境适宜性_Wetness_Buffer_汇总.xlsx"  # 输入Excel文件路径
output_excel = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\大安筛选版\水分和生境适宜性_Wetness_Buffer_汇总修改加折线.xlsx"   # 输出Excel文件路径

# ----------------------------------------------------
# 步骤1：生成缓冲区标签列表
# ----------------------------------------------------
buffer_labels = [f"{i * 100}-{(i + 1) * 100}" for i in range(15)]  # 生成0-100到1400-1500的标签

# ----------------------------------------------------
# 步骤2：处理所有工作表
# ----------------------------------------------------
with pd.ExcelWriter(output_excel, engine='openpyxl') as writer:
    # 读取原始Excel文件
    wb = load_workbook(input_excel)

    # 遍历所有工作表
    for sheet_name in wb.sheetnames:
        # 读取数据到DataFrame
        df = pd.read_excel(input_excel, sheet_name=sheet_name)

        # ----------------------------------------------------
        # 步骤3：添加新列并重命名
        # ----------------------------------------------------
        df["Buffer"] = buffer_labels  # 添加缓冲区列
        df.rename(columns={"MEAN": "Habitat_suitability_mean"}, inplace=True)  # 重命名列

        # 将处理后的数据写回新工作表
        df.to_excel(writer, sheet_name=sheet_name, index=False)

        # ----------------------------------------------------
        # 步骤4：创建折线图
        # ----------------------------------------------------
        # 获取当前工作表对象
        ws = writer.sheets[sheet_name]

        # 创建折线图对象
        chart = LineChart()
        chart.title = f"Habitat Suitability - {sheet_name}"
        chart.style = 10  # 预定义样式
        chart.y_axis.title = "Habitat Suitability"
        chart.x_axis.title = "Buffer Distance (m)"
        chart.height = 15
        chart.width = 20
        chart.legend = None

        # 设置纵轴范围为0-1
        chart.y_axis.scaling.min = 0.4
        chart.y_axis.scaling.max = 1

        # 定义数据范围 (假设数据从第2行开始)
        data = Reference(ws,
                         min_col=df.columns.get_loc("Habitat_suitability_mean")+1 ,
                         min_row=1,
                         max_row=len(df) + 1)

        # 定义分类轴（X轴）数据
        categories = Reference(ws,
                               min_col=df.columns.get_loc("Buffer") +1,
                               min_row=2,
                               max_row=len(df) + 1)

        # 添加数据到图表
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(categories)

        # 平滑折线 + 添加点标记
        for series in chart.series:
            # 设置平滑线
            series.smooth = True

            # 添加圆形标记（其他可选值：square/triangle/diamond等）
            series.marker.symbol = "circle"
            series.marker.size = 8  # 标记大小

            # 标记填充颜色（RGB：橙色）
            # series.marker.graphicalProperties.solidFill = "#4F81BD"

            # 标记边框颜色（RGB：黑色）
            # series.marker.graphicalProperties.line.solidFill = "#4F81BD"
            # 将图表插入工作表（位置可调整）
        ws.add_chart(chart, "G2")  # 图表从G2单元格开始

# ----------------------------------------------------
# 完成提示
# ----------------------------------------------------
print(f"处理完成！输出文件已保存至：{output_excel}")

