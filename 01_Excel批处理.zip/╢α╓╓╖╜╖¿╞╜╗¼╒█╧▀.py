import pandas as pd
import os
from scipy.signal import savgol_filter


def smooth_data(df, method='moving_average',  ** params):
    """数据平滑处理函数（增强列名兼容性）"""
    try:
        # 列名模糊匹配（不区分大小写、空格、下划线）
        col_map = {
            'oid': [c for c in df.columns if 'oid' in c.lower().replace(' ', '')][0],
            'water': [c for c in df.columns if 'water' in c.lower().replace(' ', '')][0],
            'habitat': [c for c in df.columns if 'habitat' in c.lower().replace(' ', '')][0]
        }

        df = df[[col_map['oid'], col_map['water'], col_map['habitat']]].copy()
        df.columns = ['OID', 'Water', 'Habitat']

        # 数据清洗（保留至少10个数据点）
        df = df.apply(pd.to_numeric, errors='coerce').dropna()
        if len(df) < 10:
            raise ValueError("有效数据不足（<10行），无法处理")

        if method == 'moving_average':
            window = max(3, params.get('window_size', 7))
            df['Water_smoothed'] = df['Water'].rolling(window, center=True, min_periods=1).mean()
            df['Habitat_smoothed'] = df['Habitat'].rolling(window, center=True, min_periods=1).mean()

        elif method == 'savitzky_golay':
            window = max(5, params.get('window_size', 15))
            order = max(2, params.get('order', 3))
            df['Water_smoothed'] = savgol_filter(df['Water'], window, order)
            df['Habitat_smoothed'] = savgol_filter(df['Habitat'], window, order)

        return df[['OID', 'Water_smoothed', 'Habitat_smoothed']]

    except Exception as e:
        raise RuntimeError(f"数据处理失败: {str(e)}") from e


def process_excel(input_path, output_path, method='moving_average',  ** params):
    """处理整个Excel文件（修复模式问题）"""
    # 验证输入文件
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"输入文件不存在: {input_path}")

    processed_count = 0
    try:
        # 创建新Excel文件（覆盖模式）
        with pd.ExcelWriter(output_path, engine='openpyxl', mode='w') as writer:
            # 读取原始文件
            xls = pd.ExcelFile(input_path, engine='openpyxl')

            for sheet_name in xls.sheet_names:
                try:
                    print(f"\n正在处理工作表: {sheet_name}")
                    df_raw = pd.read_excel(xls, sheet_name)

                    # 执行平滑处理
                    df_smoothed = smooth_data(df_raw, method=method,  ** params)

                    # 生成新sheet名称（确保唯一性）
                    new_sheet_name = f"{sheet_name[:25]}_smoothed"
                    df_smoothed.to_excel(
                        writer,
                        sheet_name=new_sheet_name,
                        index=False
                    )
                    processed_count += 1
                    print(f"成功处理: {new_sheet_name}")

                except Exception as e:
                    print(f"处理失败: {str(e)}")
                    continue

            # 至少创建一个可见sheet
            if processed_count == 0:
                pd.DataFrame().to_excel(writer, sheet_name="Empty")
                print("警告：所有工作表处理失败，已创建空表")

    except Exception as e:
        raise RuntimeError(f"处理失败: {str(e)}") from e
    finally:
        print(f"处理完成，成功处理 {processed_count} 个工作表")


if __name__ == '__main__':
    # 配置参数（确保路径正确）
    input_file = r"E:\文档\Python_Document\pythonProject\original.xlsx"
    input_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\水分和生境适宜性_汇总修改加折线.xlsx"
    output_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\水分和生境适宜性_汇总修改加折线平滑.xlsx"

    # 执行处理（建议先用小文件测试）
    process_excel(
        input_file,
        output_file,
        method='moving_average',
        window_size=7
    )