from openpyxl import load_workbook
from openpyxl.chart import LineChart, Reference


def add_line_charts(input_path, output_path):
    """
    修正图例显示的版本
    横坐标：OID
    数据列：Water_frequency 和 Habitat_suitability
    """
    # 加载工作簿
    wb = load_workbook(input_path)

    # 遍历所有工作表
    for sheet in wb.worksheets:
        # 跳过没有数据的工作表
        if sheet.max_row < 2:
            continue

        # 创建折线图对象
        chart = LineChart()
        chart.title = "Wetness vs Habitat Suitability Trend"
        chart.style = 13
        chart.y_axis.title = 'Value'
        chart.x_axis.title = 'Distance'
        chart.height = 12
        chart.width = 16

        # 定义数据范围（包含标题）
        data = Reference(sheet,
                         min_col=2,  # Water_frequency在第2列
                         max_col=3,  # Habitat_suitability在第3列
                         min_row=1,  # 包含标题行！！！
                         max_row=sheet.max_row)

        # 定义横坐标范围（OID在第1列，不含标题）
        categories = Reference(sheet,
                               min_col=1,
                               min_row=2,  # 从数据行开始
                               max_row=sheet.max_row)

        # 添加数据并应用标题
        chart.add_data(data, titles_from_data=True)  # 关键修正：从数据范围获取标题
        chart.set_categories(categories)

        # +++ 新增代码：设置纵轴范围0-1 +++
        chart.y_axis.scaling.min = 0
        chart.y_axis.scaling.max = 1

        chart.x_axis.scaling.min = 0
        chart.x_axis.scaling.max = 50

        # +++ 新增代码：设置图例位置在横轴下方（底部） +++
        chart.legend.position = 'b'

        # 自定义线条样式
        series_water = chart.series[0]
        series_habitat = chart.series[1]

        # 设置颜色
        series_water.graphicalProperties.line.solidFill = "0072B2"  # 蓝色
        series_habitat.graphicalProperties.line.solidFill = "D55E00"  # 橙色

        # --- 新增代码：设置数据点标记 ---
        # from openpyxl.drawing.fill import SolidFill

        # # 水频率数据点样式（蓝色实心圆）
        # series_water.marker.symbol = "circle"  # 圆形标记
        # series_water.marker.size = 6  # 点的大小（单位：磅）
        # series_water.marker.graphicalProperties.solidFill = "0072B2"  # 填充色与线条一致
        # series_water.marker.graphicalProperties.line.noFill = True  # 边框无色
        #
        # # 生境适宜性数据点样式（橙色实心圆）circle
        # series_habitat.marker.symbol = "circle"
        # series_habitat.marker.size = 6
        # series_habitat.marker.graphicalProperties.solidFill = "D55E00"
        # series_habitat.marker.graphicalProperties.line.noFill = True

        # 添加平滑曲线
        series_water.smooth = True
        series_habitat.smooth = True

        # 将图表插入工作表
        sheet.add_chart(chart, "H2")

    # 保存文件
    wb.save(output_path)



# 使用示例
# input_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\大安筛选版\水分和生境适宜性_Wetness_Frog_Buffer_汇总.xlsx"
# output_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\大安筛选版\水分和生境适宜性_Wetness_Frog_Buffer_汇总修改加折线.xlsx"
input_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Buffer_Statistic\Lake_3_buffer_statistic\Lake_3_buffer_re.xlsx"
output_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Buffer_Statistic\Lake_3_buffer_statistic\Lake_3_buffer_picture.xlsx"
add_line_charts(input_file, output_file)