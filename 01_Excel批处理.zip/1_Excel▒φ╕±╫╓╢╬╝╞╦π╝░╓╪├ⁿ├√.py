# import pandas as pd
#
#
# def process_excel(input_path, output_path):
#     xls = pd.ExcelFile(input_path)
#
#     with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
#         for sheet_name in xls.sheet_names:
#             df = pd.read_excel(xls, sheet_name=sheet_name)
#
#             new_sheet_name = sheet_name.replace(".shp", "")  # 直接替换所有.shp出现
#
#             # 第一步：计算并取整Distance字段
#             max_b = df['pointid'].max()
#             # 新增round().astype(int)实现四舍五入取整
#             df['Distance'] = ((8000 / max_b) * df['FID'] - 4000).round().astype(int)
#
#             # 第二步：归一化grid_code
#             min_grid = df['grid_code'].min()
#             max_grid = df['grid_code'].max()
#             df['Wetness_normalization'] = (df['grid_code'] - min_grid) / (max_grid - min_grid) if (
#                         max_grid != min_grid) else 0.5
#
#             # 第三步：归一化Frog_newpo
#             min_frog = df['Frog_newpo'].min()
#             max_frog = df['Frog_newpo'].max()
#             df['Habitat_suitability_normalization'] = (df['Frog_newpo'] - min_frog) / (max_frog - min_frog) if (
#                         max_frog != min_frog) else 0.5
#
#             # 调整列顺序（新增空列E）
#             df.insert(4, 'E', None)
#             columns_order = [
#                 'FID', 'pointid', 'grid_code', 'Frog_newpo', 'E',
#                 'Distance', 'Wetness_normalization', 'Habitat_suitability_normalization'
#             ]
#             df.to_excel(writer, sheet_name=new_sheet_name, index=False)
#             # df = df[columns_order]
#             #
#             # df.to_excel(writer, sheet_name=sheet_name, index=False)
#
#
# if __name__ == "__main__":
#     input_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\newResults\smooth55_8Km\Table_FrogDIY_Wetness.xlsx"
#     output_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\newResults\smooth55_8Km\Table_FrogDIY_Wetness修改.xlsx"
#     process_excel(input_file, output_file)
#     print("处理完成，工作表名称已去除.shp后缀")


import pandas as pd


def process_excel(input_path, output_path):
    xls = pd.ExcelFile(input_path)

    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
        for sheet_name in xls.sheet_names:
            df = pd.read_excel(xls, sheet_name=sheet_name)

            # 处理工作表名称
            clean_name = sheet_name.replace(".shp", "")

            # 计算Distance字段
            max_b = df['pointid'].max()
            # df['Distance'] = ((8000 / max_b) * df['FID'] - 4000).round().astype(int)
            df['Distance'] = (30 * df['FID'] - 15 * max_b).round().astype(int)

            # 归一化处理
            # Wetness_normalization
            min_grid = df['grid_code'].min()
            max_grid = df['grid_code'].max()
            df['Wetness_normalization'] = (df['grid_code'] - min_grid) / (max_grid - min_grid) if (
                        max_grid != min_grid) else 0.5

            # Habitat_suitability_normalization
            min_frog = df['Frog_newpo'].min()
            max_frog = df['Frog_newpo'].max()
            df['Habitat_suitability_normalization'] = (df['Frog_newpo'] - min_frog) / (max_frog - min_frog) if (
                        max_frog != min_frog) else 0.5

            # 新增平滑处理
            def smooth_column(series):
                return series[::-1].rolling(
                    window=10,
                    min_periods=1
                ).mean()[::-1].reset_index(drop=True)

            df['Wetness_normalization'] = smooth_column(df['Wetness_normalization'])
            df['Habitat_suitability_normalization'] = smooth_column(df['Habitat_suitability_normalization'])

            # 调整列结构
            df.insert(4, 'E', None)
            columns_order = [
                'FID', 'pointid', 'grid_code', 'Frog_newpo', 'E',
                'Distance', 'Wetness_normalization', 'Habitat_suitability_normalization'
            ]
            df = df[columns_order]

            # 写入处理后的数据
            df.to_excel(writer, sheet_name=clean_name, index=False)


if __name__ == "__main__":
    # input_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\newResults\smooth55_8Km\Table_FrogDIY_Wetness.xlsx"
    # output_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\newResults\smooth55_8Km\Table_FrogDIY_Wetness修改.xlsx"
    # input_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Table_Excel\Frog_Wet_1.xlsx"
    # output_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Table_Excel\Frog_Wet_1_re.xlsx"
    # input_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Table_Excel\Frog_Wet_2.xlsx"
    # output_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Table_Excel\Frog_Wet_2_re.xlsx"
    input_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Table_Excel\Frog_Wet_3.xlsx"
    output_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Table_Excel\Frog_Wet_3_re.xlsx"
    process_excel(input_file, output_file)
    print("处理完成，包含以下改进：")
    print("1. 工作表名称已去除.shp后缀\n2. Distance字段保留整数\n3. 新增平滑处理")