import pandas as pd


def process_excel(input_path, output_path):
    xls = pd.ExcelFile(input_path)

    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
        for sheet_name in xls.sheet_names:
            df = pd.read_excel(xls, sheet_name=sheet_name)

            # 处理工作表名称
            clean_name = sheet_name.replace(".shp", "")

            # 计算Distance字段
            max_b = df['pointid'].max()
            df['Distance'] = (30 * df['FID'] - 15 * max_b).round().astype(int)

            # 归一化处理
            # Wetness_normalization
            min_grid = df['grid_code'].min()
            max_grid = df['grid_code'].max()
            df['Wetness_normalization'] = (df['grid_code'] - min_grid) / (max_grid - min_grid) if (
                        max_grid != min_grid) else 0.5

            # Habitat_suitability_normalization
            min_frog = df['Frog_newpo'].min()
            max_frog = df['Frog_newpo'].max()
            df['Habitat_suitability_normalization'] = (df['Frog_newpo'] - min_frog) / (max_frog - min_frog) if (
                        max_frog != min_frog) else 0.5

            # 改进后的平滑处理函数
            def improved_smooth(series):
                # 使用居中窗口，仅当有完整11个数据点时计算均值
                smoothed = series.rolling(
                    window=11,
                    min_periods=11,  # 必须满足11个点才计算
                    center=True  # 居中窗口
                ).mean()
                # 无法满足条件的行保持原始值
                return smoothed.fillna(series)

            # 应用改进后的平滑算法
            df['Wetness_normalization'] = improved_smooth(df['Wetness_normalization'])
            df['Habitat_suitability_normalization'] = improved_smooth(df['Habitat_suitability_normalization'])

            # 调整列结构
            df.insert(4, 'E', None)
            columns_order = [
                'FID', 'pointid', 'grid_code', 'Frog_newpo', 'E',
                'Distance', 'Wetness_normalization', 'Habitat_suitability_normalization'
            ]
            df = df[columns_order]

            # 写入处理后的数据
            df.to_excel(writer, sheet_name=clean_name, index=False)


if __name__ == "__main__":
    input_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Table_Excel\Frog_Wet_1.xlsx"
    output_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Table_Excel\Frog_Wet_1_re.xlsx"
    process_excel(input_file, output_file)