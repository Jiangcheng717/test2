import os
import win32com.client as win32

# --------------------------------------------
# 用户需修改以下两个参数
# --------------------------------------------
# input_excel = r"F:\你的Excel文件.xlsx"  # 输入Excel完整路径
# output_folder = r"F:\输出图片文件夹"  # 输出文件夹路径
input_excel = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\大安筛选版\水分和生境适宜性_Wetness_Buffer_汇总修改加折线.xlsx"
output_folder = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Pictures\Wetness_Buffer"

# --------------------------------------------

def export_charts_to_images(excel_path, output_dir):
    """将Excel文件中所有工作表的图表导出为图片"""
    try:
        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)

        # 启动Excel应用程序
        excel = win32.gencache.EnsureDispatch('Excel.Application')
        excel.Visible = False  # 隐藏Excel界面

        # 打开工作簿
        wb = excel.Workbooks.Open(excel_path)

        # 遍历每个工作表
        for sheet in wb.Sheets:
            # 遍历工作表中的所有图表
            for idx, chart_obj in enumerate(sheet.ChartObjects(), 1):
                # 构建输出路径（工作表名 + 序号）
                sheet_name = clean_filename(sheet.Name)
                output_path = os.path.join(
                    output_dir,
                    f"{sheet_name}_chart{idx}.png"  # 格式：工作表名_chart1.png
                )

                # 导出为PNG图片（可修改格式）
                chart_obj.Chart.Export(output_path)
                print(f"已导出：{output_path}")

        print(f"处理完成！共导出 {wb.Sheets.Count} 个工作表的图表。")

    except Exception as e:
        print(f"错误发生：{str(e)}")
    finally:
        # 确保关闭Excel进程
        if 'wb' in locals():
            wb.Close(SaveChanges=False)
        if 'excel' in locals():
            excel.Quit()
        # 释放COM资源
        win32.pythoncom.CoUninitialize()


def clean_filename(name):
    """清理非法文件名字符"""
    return "".join(c if c.isalnum() or c in ('_', '-') else '_' for c in name)


# 执行导出
if __name__ == "__main__":
    export_charts_to_images(input_excel, output_folder)