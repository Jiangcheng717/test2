import pandas as pd
import numpy as np


def process_sheet(df, y_columns, slope_prefix):
    """
    处理单个工作表，进行多项式拟合、计算R²和斜率
    :param df: 输入数据框
    :param y_columns: 需要处理的Y列列表
    :param slope_prefix: 斜率列前缀
    :return: 处理后的数据框和R²结果字典
    """
    x = df['Distance'].values
    results = {}

    for col in y_columns:
        y = df[col].values

        # 6次多项式拟合
        coeffs = np.polyfit(x, y, 6)

        # 计算R²
        y_pred = np.polyval(coeffs, x)
        ss_res = np.sum((y - y_pred) ** 2)
        ss_tot = np.sum((y - np.mean(y)) ** 2)
        r_squared = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0
        results[col] = r_squared

        # 计算导数系数（斜率多项式）
        derivative_coeffs = [coeffs[i] * (6 - i) for i in range(6)]

        # 计算每个点的斜率
        slopes = np.polyval(derivative_coeffs, x)

        # 添加斜率列
        df[f'Slope_{slope_prefix}{col.split("_")[-1]}'] = slopes

    return df, results


# 读取Excel文件
input_file = r"F:\08霍林河水份梯度\结果展示\Data_Important\ImporentData\Table_Excel\Buffer_Statistics\Lake_Frog_Summary.xlsx"
reclass_df = pd.read_excel(input_file, sheet_name='ReclassSum')
frogmean_df = pd.read_excel(input_file, sheet_name='FrogMean')

# 处理ReclassSum表
processed_reclass, reclass_results = process_sheet(
    reclass_df,
    ['Sum/Area_1', 'Sum/Area_2', 'Sum/Area_3'],
    'Area_'
)

# 处理FrogMean表
processed_frogmean, frogmean_results = process_sheet(
    frogmean_df,
    ['MEAN_1', 'MEAN_2', 'MEAN_3'],
    'MEAN_'
)

# 创建结果汇总
summary_data = {
    'Sheet': ['ReclassSum'] * 3 + ['FrogMean'] * 3,
    'Column': list(reclass_results.keys()) + list(frogmean_results.keys()),
    'R²': list(reclass_results.values()) + list(frogmean_results.values())
}

summary_df = pd.DataFrame(summary_data)

# 保存结果到新Excel文件
output_file=r"F:\08霍林河水份梯度\结果展示\Data_Important\ImporentData\Table_Excel\Buffer_Statistics\Lake_Frog_Summary_fx.xlsx"
with pd.ExcelWriter(output_file) as writer:
    processed_reclass.to_excel(writer, sheet_name='ReclassSum_Processed', index=False)
    processed_frogmean.to_excel(writer, sheet_name='FrogMean_Processed', index=False)
    summary_df.to_excel(writer, sheet_name='Summary', index=False)

print("处理完成，结果已保存到 analysis_results.xlsx")
print("\nR²汇总:")
print(summary_df)