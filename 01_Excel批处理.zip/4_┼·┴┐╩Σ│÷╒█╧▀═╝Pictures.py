import win32com.client as win32
import os


def export_charts(excel_path, output_folder):
    # 确保输出目录存在
    os.makedirs(output_folder, exist_ok=True)

    # 启动Excel应用
    excel = win32.gencache.EnsureDispatch('Excel.Application')
    excel.Visible = False  # 不显示界面

    try:
        workbook = excel.Workbooks.Open(os.path.abspath(excel_path))

        # 遍历所有工作表
        for sheet in workbook.Sheets:
            original_name = sheet.Name
            # 处理文件名（移除.dbf后缀）
            if original_name.endswith('.shp'):
                image_name = original_name[:-4] + '.png'
            else:
                image_name = original_name + '.png'

            image_path = os.path.join(output_folder, image_name)

            # 检查是否存在图表
            if sheet.ChartObjects().Count > 0:
                # 获取第一个图表（假设每个表只有一个）
                chart = sheet.ChartObjects(1).Chart
                chart.Export(image_path)
                print(f'导出成功: {image_name}')
            else:
                print(f'工作表 {original_name} 中没有图表')

        workbook.Close(SaveChanges=False)
    except Exception as e:
        print(f'发生错误: {str(e)}')
    finally:
        excel.Quit()


if __name__ == '__main__':

    # excel_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\大安筛选版\水分和生境适宜性_汇总修改加折线.xlsx"
    # output_dir = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Pictures"
    # excel_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\大安筛选版\水分和生境适宜性_Wetness_3Km_汇总修改加折线.xlsx"
    # output_dir = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Pictures\Wetness_3Km"
    # excel_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Table_Excel\newResults\smooth55_8Km\Table_FrogDIY_Wetness修改加折线.xlsx"
    # output_dir = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\Pictures\Wetness_8Km"
    excel_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Table_Excel\Frog_Wet_1_re_picture.xlsx"
    output_dir = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Pictures\1单独"
    # excel_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Table_Excel\Frog_Wet_2_re_picture.xlsx"
    # output_dir = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Pictures\2串状"
    # excel_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Table_Excel\Frog_Wet_3_re_picture.xlsx"
    # output_dir = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Pictures\3湖泊群"

    excel_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Buffer_Statistic\Lake_3_buffer_statistic\Lake_3_buffer_picture.xlsx"
    output_dir = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Pictures\Buffer_Pictures\3集群"
    export_charts(excel_file, output_dir)