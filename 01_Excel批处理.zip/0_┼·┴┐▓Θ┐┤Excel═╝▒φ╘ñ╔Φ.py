from openpyxl import Workbook
from openpyxl.chart import LineChart, Reference
import pandas as pd

# 创建测试数据
data = {
    "Buffer": ["0-100", "100-200", "200-300"],
    "Habitat": [0.2, 0.5, 0.8]
}
df = pd.DataFrame(data)

# 创建工作簿
wb = Workbook()
ws = wb.active

# 写入测试数据
for row in dataframe_to_rows(df, index=False, header=True):
    ws.append(row)

# 为每个样式生成图表
for style_num in range(1, 49):
    chart = LineChart()
    chart.title = f"Style {style_num}"
    chart.style = style_num  # 设置样式编号

    # 绑定数据范围
    data = Reference(ws, min_col=2, min_row=1, max_row=4)
    categories = Reference(ws, min_col=1, min_row=2, max_row=4)
    chart.add_data(data, titles_from_data=True)
    chart.set_categories(categories)

    # 将图表插入工作表（每行4个图表）
    col_offset = ((style_num - 1) % 4) * 8  # 横向间隔
    row_offset = ((style_num - 1) // 4) * 15  # 纵向间隔
    ws.add_chart(chart, f"E{row_offset + 1}")

# 保存文件
wb.save("chart_styles_preview.xlsx")