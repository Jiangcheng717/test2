import pandas as pd

# 输入输出路径
input_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Buffer_Statistic\Lake_3_buffer_statistic\Lake_3_buffer.xlsx"
output_file = r"F:\08霍林河水份梯度\Data\ArcgisPro\米字形网格\ImporentData\Buffer_Statistic\Lake_3_buffer_statistic\Lake_3_buffer_re.xlsx"

# 读取所有sheet
all_sheets = pd.read_excel(input_file, sheet_name=None)

# 处理每个工作表
for sheet_name, df in all_sheets.items():
    # 计算新Distance列（使用原始FID数据）
    df.insert(0, "Distance", df["FID"] * 30 + 30)  # 插入到第一列

    # 删除原始FID列
    df.drop("FID", axis=1, inplace=True)

    # 重命名Habitat列
    df.rename(columns={"Habitat": "Habitat_suitability"}, inplace=True)

    # 保持列顺序：Distance, Wetness, Habitat_suitability
    df = df[["Distance", "Wetness", "Habitat_suitability"]]

# 输出到新文件（保留原始sheet结构）
with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
    for sheet_name, df in all_sheets.items():
        df.to_excel(writer, sheet_name=sheet_name, index=False)

print(f"处理完成！结果已保存至：{output_file}")