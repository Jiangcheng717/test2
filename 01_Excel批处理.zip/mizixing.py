# -*- coding: utf-8 -*-
import arcpy
import math


def generate_cross_lines():
    try:
        # 输入参数
        input_points = arcpy.GetParameterAsText(0)
        output_lines = arcpy.GetParameterAsText(1)
        line_length = float(arcpy.GetParameterAsText(2))

        # 坐标系验证
        desc = arcpy.Describe(input_points)
        if desc.spatialReference.type != "Projected":
            arcpy.AddError("必须使用投影坐标系！")
            return

        # 创建输出要素
        arcpy.management.CreateFeatureclass(
            out_path=arcpy.env.workspace,
            out_name=output_lines,
            geometry_type="POLYLINE",
            spatial_reference=desc.spatialReference
        )

        # 添加字段
        arcpy.management.AddField(output_lines, "SourceID", "LONG")

        # 游标操作
        with arcpy.da.InsertCursor(output_lines, ["SHAPE@", "SourceID"]) as iCur:
            with arcpy.da.SearchCursor(input_points, ["SHAPE@XY", "OID@"]) as sCur:
                for s_row in sCur:
                    x, y = s_row[0]
                    oid = s_row[1]
                    half = line_length / 2

                    # 四个方向角度
                    angles = [0, 90, 45, 135]
                    for angle in angles:
                        rad = math.radians(angle)
                        dx = half * math.cos(rad)
                        dy = half * math.sin(rad)

                        # 生成线几何
                        p1 = arcpy.Point(x - dx, y - dy)
                        p2 = arcpy.Point(x + dx, y + dy)
                        line = arcpy.Polyline(arcpy.Array([p1, p2]))

                        # 写入要素 ← 关键缩进层级
                        iCur.insertRow([line, oid])  # ✅ 正确缩进

        arcpy.AddMessage(f"生成成功：{arcpy.management.GetCount(output_lines)[0]}条线")

    except Exception as e:
        arcpy.AddError(f"运行错误: {str(e)}")


if __name__ == "__main__":
    generate_cross_lines()